#ifndef JJCONFIG_H
#define JJCONFIG_H

#endif // JJCONFIG_H
