#include <cstdio>

int main(int argc, char ** argv)
{
  (void) argc;
  (void) argv;

  printf("hello world usb_camera_node package\n");
  return 0;
}
