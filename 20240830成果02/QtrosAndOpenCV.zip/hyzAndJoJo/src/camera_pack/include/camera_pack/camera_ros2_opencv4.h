// #include <ros/ros.h>
// #include "rclcpp/rclcpp.hpp"
#include <cstdio>
#include <unistd.h>
// int main(int argc, char **argv)
// {
//     ros::init(argc, argv, "camera_ros2_opencv4");
//     ros::NodeHandle nh;

//     ROS_INFO("Hello world!");
// }
