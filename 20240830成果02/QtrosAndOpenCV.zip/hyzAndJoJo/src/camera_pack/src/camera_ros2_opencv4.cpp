// #include <ros/ros.h>
// #include "rclcpp3.hpp"


#include <string>
#include <octomap/AbstractOccupancyOcTree.h>
// #include "qlibrary.h"

#include <opencv4/opencv2/opencv.hpp>

// #include <cstdio>
// #include <unistd.h>

// #include <stdio.h>
// #include <string.h>
// #include <stdlib.h>
#include <iostream>

int main()
{


  for(int a=1;a<10000;a++){


    printf("hello world camera_pack package\n");

    std::cout<<"hello1"<<std::endl;
    std::cerr<<"hello2"<<std::endl;
    std::clog<<"hello3"<<std::endl;



  }
  return 0;
}
